import PropTypes from 'prop-types';

const Buttonbuy = (props) => {
    return (
      <button 
        className={`h-10 px-6 font-semibold rounded-md ${props.variant} text-white`}
        type='submit'
      >
        {props.children}
      </button>
    );
}

Buttonbuy.propTypes = {
    variant: PropTypes.string.isRequired, // memastikan variant adalah string dan wajib
    children: PropTypes.node,             // children bisa berupa teks atau elemen React
};

Buttonbuy.defaultProps = {
    variant: 'bg-black',   // default class untuk variant
    children: '...',       // default konten untuk tombol
};

export default Buttonbuy;
