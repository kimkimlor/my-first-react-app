import Input from './Input';
import Label from './Label';

export { Input, Label };