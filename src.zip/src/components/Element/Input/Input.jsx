import PropTypes from 'prop-types';

const Input = (props) => {
    return <input className={`w-full rounded-md ${props.variant}`} type={props.type} placeholder={props.placeholder} />
}

Input.propTypes = {
    variant: PropTypes.string.isRequired,
};

Input.defaultProps = {
    variant: 'text-black',
}

export default Input;