import PropTypes from 'prop-types';

const Label = (props) => {
    return <p className="text-{props.variant}">{props.children}</p>
}

Label.propTypes = {
    variant: PropTypes.string.isRequired,
};

Label.defaultProps = {
    variant: 'text-black',
    children: '...',
}

export default Label